﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Brandy.Grapes")]
[assembly: Guid("A9E3A318-5F01-48D1-A711-2D2433B80DB5")]
[assembly: InternalsVisibleTo("Brandy.Grapes.EntityFramework")]
[assembly: InternalsVisibleTo("Brandy.Grapes.NHibernate")]
