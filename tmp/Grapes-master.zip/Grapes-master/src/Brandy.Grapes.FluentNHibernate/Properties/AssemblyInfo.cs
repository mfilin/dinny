﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Brandy.Grapes.NHibernate")]
[assembly: Guid("CE07A4EC-19CF-498B-A26C-7C7A7931CF8B")]