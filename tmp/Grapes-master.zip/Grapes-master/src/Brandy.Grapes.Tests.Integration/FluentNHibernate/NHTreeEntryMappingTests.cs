namespace Brandy.Trees.Tests.Integration.FluentNHibernate
{
    using Infrastructure;

    public class NHTreeEntryMappingTests : TreeEntryMappingTestsBase<NHUnitOfWorkFactory>
    {
    }
}