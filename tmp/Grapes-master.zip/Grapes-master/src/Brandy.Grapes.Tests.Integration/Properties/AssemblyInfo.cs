﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Brandy.Grapes.Tests.Integration")]
[assembly: Guid("2bbe582f-e657-418f-8f85-de87205d7de3")]