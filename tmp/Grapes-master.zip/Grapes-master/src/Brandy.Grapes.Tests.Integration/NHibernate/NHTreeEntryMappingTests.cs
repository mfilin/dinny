namespace Brandy.Trees.Tests.Integration.NHibernate
{
    using Infrastructure;

    public class NHTreeEntryMappingTests : TreeEntryMappingTestsBase<NHUnitOfWorkFactory>
    {
    }
}