﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Brandy.Grapes.Tests")]
[assembly: Guid("b9cb1de7-f1d7-449d-9ffd-91b10bf04f9c")]